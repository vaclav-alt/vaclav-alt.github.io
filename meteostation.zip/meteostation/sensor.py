import datetime
from abc import ABC, abstractmethod
from dataclasses import dataclass

import numpy as np
from meteostation.perlin import PerlinWithOctaves


@dataclass
class SensorReading:
    timestamp: datetime.datetime
    value: float
    units: str


class Sensor(ABC):
    def __init__(self, interval_seconds):
        self.interval_seconds = datetime.timedelta(seconds=interval_seconds)
        self.last_val = None
        self.last = datetime.datetime.now()
        self.start = self.last
        self.unit = ""

    def read(self) -> SensorReading:
        self.last += self.interval_seconds
        self.last_val = self._generate()

        return SensorReading(self.last, self.last_val, self.unit)

    @abstractmethod
    def _generate(self):
        pass


class TemperatureSensor(Sensor):
    def __init__(self, interval_seconds):
        super().__init__(interval_seconds)
        self.generator = PerlinWithOctaves(2, 1, baseamp=10, gradient_fac=0.5)
        self.unit = "˚C"

    def _generate(self):
        td = self.last - self.start
        t = td.microseconds / 1000
        y = 10 / (np.exp(0.5 * (t - 10)) + 1) + 15
        noise = next(self.generator)
        return y + noise


class WindSensor(Sensor):
    def __init__(self, interval_seconds):
        super().__init__(interval_seconds)
        self.generator = PerlinWithOctaves(8, 3, baseamp=5, gradient_fac=1)
        self.unit = "m/s"

    def _generate(self):
        noise = next(self.generator)
        return noise


class PressureSensor(Sensor):
    def __init__(self, interval_seconds):
        super().__init__(interval_seconds)
        self.generator = PerlinWithOctaves(2, 1, baseamp=10, gradient_fac=0.5)
        self.unit = "hPa"

    def _generate(self):
        noise = 1013 + next(self.generator)
        return noise
