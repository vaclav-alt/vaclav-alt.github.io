from meteostation.perlin import PerlinWithOctaves
import datetime
import time
import matplotlib.pyplot as plt
import numpy as np

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class SensorReading:
    timestamp: datetime.datetime
    value: float
    units: str


class Sensor(ABC):
    def __init__(self, interval_seconds):
        self.interval_seconds = datetime.timedelta(seconds=interval_seconds)
        self.last_val = None
        self.last = datetime.datetime.now()
        self.start = self.last
        self.unit = ""

    def read(self) -> SensorReading:
        now = datetime.datetime.now()
        if now - self.last > self.interval_seconds or self.last_val is None:
            self.last = now
            self.last_val = self._generate()

        return SensorReading(now, self.last_val, self.unit)

    @abstractmethod
    def _generate(self):
        pass

class TemperatureSensor(Sensor):
    def __init__(self, interval_seconds):
        super().__init__(interval_seconds)
        self.generator = PerlinWithOctaves(2, 1, baseamp=10, gradient_fac=0.5)
        self.unit = "˚C"

    def _generate(self):
        td = self.last - self.start
        t = td.microseconds / 1000
        y = 10 / (np.exp(0.5 * (t - 10)) + 1) + 15
        noise = next(self.generator)
        return y + noise

class WindSensor(Sensor):
    def __init__(self, interval_seconds):
        super().__init__(interval_seconds)
        self.generator = PerlinWithOctaves(8, 3, baseamp=5, gradient_fac=1)
        self.unit = "m/s"

    def _generate(self):
        noise = next(self.generator)
        return noise

class PressureSensor(Sensor):
    def __init__(self, interval_seconds):
        super().__init__(interval_seconds)
        self.generator = PerlinWithOctaves(2, 1, baseamp=10, gradient_fac=0.5)
        self.unit = "hPa"


    def _generate(self):
        noise = 1013 + next(self.generator)
        return noise

def main():
    sensor = TemperatureSensor(1.5)
    wind_sensor = WindSensor(0.2)
    press_sensor = PressureSensor(0.2)
    vals = []
    wind_vals = []
    press_vals = []
    for _ in range(20):
        val = sensor.read()
        vals.append(val)
        wind_val = wind_sensor.read()
        wind_vals.append(wind_val)
        press_val = press_sensor.read()
        press_vals.append(press_val)
        time.sleep(1.0)

    fig, axs = plt.subplots(3, 1)
    axs[0].plot(vals)
    axs[1].plot(wind_vals)
    axs[2].plot(press_vals)
    plt.show()



if __name__ == "__main__":
    main()
