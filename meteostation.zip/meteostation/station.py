from meteostation.sensor import WindSensor, PressureSensor, TemperatureSensor


class MeteoStation:
    """Fake meteorological station

    Serves as a proxy to a set of sensors. Does not check whether values have change or not.
    """

    def __init__(self, timeout=1800):
        self.temp_sensor = TemperatureSensor(timeout)
        self.wind_sensor = WindSensor(timeout)
        self.press_sensor = PressureSensor(timeout)

    def read(self):
        """ Reads values from sensor within station.

        Returns:
            Dictionary of SensorReading objects, containing keys "temperature", "wind", "pressure"
        """
        return {
            "temperature": self.temp_sensor.read(),
            "wind": self.wind_sensor.read(),
            "pressure": self.press_sensor.read(),
        }
