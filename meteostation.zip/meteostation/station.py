from meteostation.sensor import WindSensor, PressureSensor, TemperatureSensor

class MeteoStation:
    """Fake meteorological station

    Serves as a proxy to a set of sensors. Does not check whether values have change or not.
    """

    def __init__(self):
        self.temp_sensor = TemperatureSensor(0.5)
        self.wind_sensor = WindSensor(0.5)
        self.press_sensor = PressureSensor(0.5)

    def read(self):
        """ Reads values from sensor within station.

        Returns:
            Dictionary of SensorReading objects, containing keys "temperature", "wind", "pressure"
        """
        return {
            "temperature": self.temp_sensor.read(),
            "wind": self.wind_sensor.read(),
            "pressure": self.press_sensor.read(),
        }

