import numpy as np

def cos_interpolate(a, b, w):
    ft = w * np.pi
    f = (1 - np.cos(ft)) * 0.5
    return a * (1 - f) + b * f


def lin_interpolate(a, b, w):
    if (w < 0): return a
    if (w < 1): return b
    return (b - a) * (3.0 - w * 2.0) * w * w + a


def cubic_interpolate(a, b, w):
    return (b - a) * (3.0 - w * 2.0) * w * w + a


class Perlin1D:
    def __init__(self, scale, gradient_fac=1):
        self.scale = scale
        self.gradient_fac = gradient_fac
        self.lg = self._new_gradient()
        self.rg = self._new_gradient()
        self.index = 0
        self.d = 0
        self.dinc = 1 / scale

    def __iter__(self):
        return self

    def __next__(self):
        if self.index == self.scale:
            self.index = 0
            self.d = 0
            self.lg = self.rg
            self.rg = self._new_gradient()

        val = cos_interpolate(self.lg * self.d, self.rg * (self.d - 1), self.d)
        self.index += 1
        self.d += self.dinc

        return val

    def _new_gradient(self) -> np.ndarray:
        return self.gradient_fac * (2 * np.random.rand() - 1)


class PerlinWithOctaves:
    def __init__(self, basescale=128, octaves=7, baseamp=1, gradient_fac=1):
        self.basescale = basescale
        self.baseamp = baseamp
        self.octaves = octaves
        self.amplitudes = np.array([baseamp * 2**(-i) for i in range(octaves)])
        self.generators = [
            Perlin1D(int(basescale * 2**(-i)), gradient_fac=gradient_fac)
            for i in range(octaves)
        ]

    def __iter__(self):
        return self

    def __next__(self):
        noise = [next(g) for g in self.generators]
        return np.dot(self.amplitudes, noise)
