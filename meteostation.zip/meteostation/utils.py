from typing import Iterable


def rotate_ax_ticks(axs, degrees: int = 45):
    """ Rotates xticks of matplotlib.axes.Axes to degrees angle.

    Args:
        axs: matplotlib Axes object or an iterable of multiple matplotlib Axes
        degrees: angle to which the xticks will be returned
    """
    if not isinstance(axs, Iterable):
        axs = [axs, ]
    for ax in axs:
        ax.set_xticks(ax.get_xticks(), ax.get_xticklabels(), rotation=degrees, ha="right")
