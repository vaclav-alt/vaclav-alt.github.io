import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output

app = dash.Dash(__name__)

pozdrav = {
    "de" : "Hallo",
    "en" : "Oi, oi",
    "cz" : "Nazdar",
    "jp" : "こんにちは"
}

app.layout = html.Div([
    html.H1("Hallo", id = "header"),
    dcc.RadioItems(
        id = "jazyk",
        options = [
            {"value" : "de", "label" : "Deutsch"},
            {"value" : "en", "label" : "English"},
            {"value" : "cz", "label" : "Česky"},
            {"value" : "jp", "label" : "日本語"}
        ],
        value = "jp"),
    html.Hr()
])

@app.callback(
    Output("header", "children"),
    Input("jazyk", "value"))
def update_hello(val):
    return pozdrav[val]

if __name__ == "__main__":
    app.run_server(debug=True, port=9050)