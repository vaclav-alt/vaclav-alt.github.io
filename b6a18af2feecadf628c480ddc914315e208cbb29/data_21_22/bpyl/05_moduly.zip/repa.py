def f():
    print("function from repa module")

    
if __name__ == "__main__":
    print("running repa as a program")
else:
    print("loading repa as a module")