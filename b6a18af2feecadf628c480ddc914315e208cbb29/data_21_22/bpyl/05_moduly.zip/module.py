import random as r

def function():
    return r.random()