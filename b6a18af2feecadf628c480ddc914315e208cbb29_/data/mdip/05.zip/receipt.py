import datetime


def get_receipt(nakup: dict, width: int = 50) -> str:
    """Creates a fixed-width receipt for a cash-register
    
    Args:
        nakup: a dictionary with items and their prices
        width: number of characters in a receipt row
        
    Returns:
        A string containing the generated receipt
    
    """
    out_str = " ÚČTENKA ".center(width, "=") + "\n"

    today = datetime.datetime.today()

    out_str += f"{today:%Y-%m-%d %H:%M}".rjust(width) + "\n"
    for key, val in nakup.items():
        fill_width = width - len(key)
        out_str += f"{key}{val:.>{fill_width}.2f}\n"

    out_str += (
        f"{'-':->{width}s}\n"
        f"Celkem (Kč)\n"
        f"{sum(nakup.values()): >{width}.2f}"
    )
    return out_str


def main():
    nakup = {
        "rohliky": 20,
        "salam": 23.9,
        "maslo": 62.5,
        "tuřín": 1348
    }

    receipt = get_receipt(nakup, 40)
    print(receipt)

    
if __name__ == "__main__":
    main()