import sys
import argparse

import numpy as np
import matplotlib.pyplot as plt

from waves import wave


def plot(kind: str, N: int):
    figsize = (9, 3)

    fig, axs = plt.subplots(1, 3, figsize=figsize)

    cmap = plt.get_cmap("inferno")
    colors = cmap(np.linspace(0, 1, N+1))

    a = 0.0
    b = 10.0

    x = np.linspace(a, b, 1000)

    data = wave(x, a=a, b=b, N=N, sum=False, kind=kind)
    axs[0].plot(x, np.sum(data[:-1], 0), color="black")
    
    for i in range(0, N):
        axs[1].plot(x, data[i], color=colors[i], label=f"N={i+1}")
        axs[2].plot(x, np.sum(data[:i], 0), color=colors[i])

    axs[1].legend()
    plt.show()
    
    
def main():
    parser = argparse.ArgumentParser(description='This program demonstrates different kinds of wave signals')
    parser.add_argument('kind', type=str, help="wave kind")
    parser.add_argument('-N', '--npartial', type=int, default=10, help="number of partial waves")
    args = parser.parse_args()
    plot(args.kind, args.npartial)
    

if __name__ == "__main__":
    main()
